<?php 

echo '<hr><div class="text-center">Le nom du demandeur est: <strong>', $_POST['nom'], '</strong> et son email <strong>', $_POST['email'], '</strong></div>';